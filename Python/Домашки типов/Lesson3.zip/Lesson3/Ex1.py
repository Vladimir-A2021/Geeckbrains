def dividing(*args):
    try:
        arg_1 = int(input("Введите делимое "))
        arg_2 = int(input("Введите делитель "))
        res = arg_1 / arg_2
    except ZeroDivisionError:
        return "Делить на 0 нельзя!"
    return res


print("Результат ", dividing())
