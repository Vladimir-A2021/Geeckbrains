def my_func(x, y):
    return 1 / x ** abs(y)
    return x ** y


print(my_func(5, -5))


def power(x, y):
    res = 1
    z = abs(y)
    while z > 0:
        res = res * x
        z -= 1
    return 1 / res


print(power(5, -5))
