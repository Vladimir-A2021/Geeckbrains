def my_func(a):
    words = a.split(' ')
    final_str = []
    for i in words:
        element = str(i)
        letter = element[:1].upper()
        word = letter + element[1:]
        final_str.append(word)
    return final_str
print(' '.join((my_func("riders on the storm"))))