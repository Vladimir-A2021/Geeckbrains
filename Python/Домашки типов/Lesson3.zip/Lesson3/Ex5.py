def summ():
    result = 0
    cycle_bool = 0
    while cycle_bool == False:
        tmp = 0
        num = input("Введите число или Q для выхода из программы ").split()

        for el in range(len(num)):
            if num[el] == 'Q':
                cycle_bool = True
                break
            else:
                tmp = tmp + int(num[el])
            result = result + tmp
        if num[el] != 'Q':
            print(f'Текущая сумма {result}')
    print(f'Конечная сумма {result}')


summ()