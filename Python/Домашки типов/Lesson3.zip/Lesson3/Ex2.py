def my_func(name, surname, year, city, mail, phone):
    return ' '.join([name, surname, year, city, mail, phone])


print(my_func(name='John', surname='Doe', year='2000', city='Los Alamos', mail='gajet@mail.ru',
              phone='+1-322-223-32-22'))
